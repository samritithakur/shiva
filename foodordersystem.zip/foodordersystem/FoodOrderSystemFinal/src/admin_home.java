

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class admin_home
 */
@WebServlet("/admin_home")
public class admin_home extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public admin_home() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String un=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		String fn=request.getParameter("firstname");
		String ln=request.getParameter("lastname");
		String b=request.getParameter("btn");
		  // try
	      //  {
		if(b.equals("Submit"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		st.executeUpdate("insert into tbl_vendor(username,password,firstname,lastname) values('"+un+"','"+pwd+"','"+fn+"','"+ln+"')");
		con.close();
		out.print("<script type='text/javascript'>alert('Data Saved Successfully');</script>");
		response.sendRedirect("admin_home.jsp");
			}catch(Exception e1){out.print(""+e1);}
		}
	}

}
