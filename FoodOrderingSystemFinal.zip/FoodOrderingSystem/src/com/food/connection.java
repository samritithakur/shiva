package com.food;


import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;




public class connection extends HttpServlet {
   public static Connection con;
	
    public connection() {
        super();
        // TODO Auto-generated constructor stub
      //  PrintWriter out=response.getWriter();
		   try
	        {
			   Class.forName("oracle.jdbc.driver.OracleDriver");
			      con = DriverManager.getConnection("jdbc:oracle:thin:@10.11.134.61:1521:orcl1", "exam_475135", "exam_475135");
			      System.out.println("Connected database successfully...");

	    
	        }catch(Exception e1){}
     
    }
    
    public Connection getConnection()
    {
    return con;
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet connection</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet connection at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "Short description";
    }
    
}
