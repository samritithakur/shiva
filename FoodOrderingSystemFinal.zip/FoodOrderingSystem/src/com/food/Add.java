
package com.food;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Add extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet add</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet add at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       // processRequest(request, response);
        
            	PrintWriter out=response.getWriter();
            HttpSession session =request.getSession();
		String un=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		String fn=request.getParameter("firstname");
		String ln=request.getParameter("lastname");
		
                
                String menutitle=request.getParameter("ddlmenutitle");
                  String food=request.getParameter("food");
                    String price=request.getParameter("price");
                    String id=request.getParameter("foodid");
                    
                    
                    String b=request.getParameter("btn");
                
		  // try
	      //  {
		if(b.equals("SubmitVendor"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		st.executeUpdate("insert into tbl_vendor(usernames,passwords,firstname,lastname) values('"+un+"','"+pwd+"','"+fn+"','"+ln+"')");
		con.close();
		//out.print("<script type='text/javascript'>alert('Data Saved Successfully');</script>");
		response.sendRedirect("admin_home.jsp");
			}catch(Exception e1){out.print(""+e1);}
		}
                    
                    
                else   if(b.equals("SubmitEmployee"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		st.executeUpdate("insert into tbl_employee(usernames,passwords,firstname,lastname) values('"+un+"','"+pwd+"','"+fn+"','"+ln+"')");
		con.close();
		//out.print("<script type='text/javascript'>alert('Data Saved Successfully');</script>");
		response.sendRedirect("admin_add_employee.jsp");
			}catch(Exception e1){out.print(""+e1);}
		}
                
                else   if(b.equals("SubmitMenu"))
		{
                   
			try
			{
                           
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		st.executeUpdate("insert into tbl_menu(vendorusername,menutitle,food,price,id) values('"+session.getAttribute("vendorusername")+"','"+menutitle+"','"+food+"','"+price+"','"+id+"')");
		con.close();
		//out.print("<script type='text/javascript'>alert('Data Saved Successfully');</script>");
		response.sendRedirect("vendor_home.jsp");
			}catch(Exception e1){out.print(""+e1);}
		}
                else   if(b.equals("order"))
		{
                   
			try
			{ java.util.Date dt=new java.util.Date();
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		st.executeUpdate("insert into tbl_order(employeeusername,foodid,dated) values('"+session.getAttribute("employeeusername")+"','"+request.getParameter("foodid")+"','"+dt.toString()+"')");
		con.close();
		//out.print("<script type='text/javascript'>alert('Data Saved Successfully');</script>");
		response.sendRedirect("employee_home.jsp");
			}catch(Exception e1){out.print(""+e1);}
		}
                
                
                
                
                
    }

    
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
