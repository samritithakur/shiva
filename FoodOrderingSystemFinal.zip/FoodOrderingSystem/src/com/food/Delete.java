package com.food;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet add</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet add at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 
 
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
        HttpSession session =request.getSession();
        String un=request.getParameter("usernames");
        String fi=request.getParameter("foodid");
        
        String b=request.getParameter("btn");
        
        if(b.equals("DeleteEmployee"))
        {
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
			Statement st=con.createStatement();
			st.executeUpdate("delete from tbl_employee where usernames  = '"+un+"'");
			response.sendRedirect("admin_home.jsp");
			con.close();
			}
			
			catch(Exception e1)
			{
				out.print(""+e1);
				}
			
			
        }
        
        else if(b.equals("DeleteVendor"))
     		{
                        
     			try
     			{ 
     			
     			connection c=new connection();
     			Connection con=c.getConnection();
     			Statement st=con.createStatement();
     			st.executeUpdate("delete from tbl_vendor where usernames  = '"+un+"'");
    			response.sendRedirect("admin_home.jsp");
    			con.close();
     		
     			}catch(Exception e1){out.print(""+e1);}
     		}
        
        else if(b.equals("DeleteMenu"))
 		{
                    
 			try
 			{ 
 			
 			connection c=new connection();
 			Connection con=c.getConnection();
 			Statement st=con.createStatement();
 			st.executeUpdate("delete from tbl_menu where id  = '"+fi+"'");
			response.sendRedirect("vendor_home.jsp");
			con.close();
 		
 			}catch(Exception e1){out.print(""+e1);}
 		}
        
        else if(b.equals("DeleteOrder"))
 		{
                    
 			try
 			{ 
 			
 			connection c=new connection();
 			Connection con=c.getConnection();
 			Statement st=con.createStatement();
 			st.executeUpdate("delete from tbl_order where foodid  = '"+fi+"'");
			response.sendRedirect("vendor_home.jsp");
			con.close();
 		
 			}catch(Exception e1){out.print(""+e1);}
 		}
        
//        else
//		{
//		   out.println("<script type=\"text/javascript\">");
//		   out.println("alert('User or password incorrect');");
//		   out.println("location='admin_login.jsp';");
//		   out.println("</script>");
//		}
        
       
        
		}
          
}
        
	


