

package com.food;



import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class login extends HttpServlet {
   
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet login</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet login at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       // processRequest(request, response);
        PrintWriter out=response.getWriter();
		String un=request.getParameter("username");
		String pwd=request.getParameter("password");
		String b=request.getParameter("btn");
                HttpSession session=request.getSession();
		  // try
	      //  {
		if(b.equals("AdminSignin"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("Select * from tbl_admin_login where usernames='"+un+"' and passwords='"+pwd+"'");
		if(rs.next())
		{
			
			response.sendRedirect("admin_home.jsp");
		}
		else
		{
		   out.println("<script type=\"text/javascript\">");
		   out.println("alert('User or password incorrect');");
		   out.println("location='admin_login.jsp';");
		   out.println("</script>");
		}

			}catch(Exception e1){out.print(""+e1);}
		
		}
                
                if(b.equals("EmployeeSignin"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("Select * from tbl_employee where usernames='"+un+"' and passwords='"+pwd+"'");
		if(rs.next())
		{
                   session.setAttribute("employeeusername", un);
			response.sendRedirect("employee_home.jsp");
		}
		else
		{
		   out.println("<script type=\"text/javascript\">");
		   out.println("alert('User or password incorrect');");
		   out.println("location='employee_login.jsp';");
		   out.println("</script>");
		}
			}catch(Exception e1){out.print(""+e1);}
		
		}
                   if(b.equals("VendorSignin"))
		{
			try
			{
			connection c=new connection();
			Connection con=c.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("Select * from tbl_vendor where usernames='"+un+"' and passwords='"+pwd+"'");
		if(rs.next())
		{
                  session.setAttribute("vendorusername", un);
			response.sendRedirect("vendor_home.jsp");
		}
		else
		{
		   out.println("<script type=\"text/javascript\">");
		   out.println("alert('User or password incorrect');");
		   out.println("location='vendor_login.jsp';");
		   out.println("</script>");
		}
			}catch(Exception e1){out.print(""+e1);}
		
		}
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
